HTMLWidgets.widget({

  name: 'sequenceViewer',

  type: 'output',

  factory: function(el, width, height) {

    // TODO: define shared variables for this instance

    return {

      renderValue: function(x) {
        // Classic display of the sequence
        var seq1 = new Sequence(x.sequence);
        // You can add some rendering options
        seq1.render("#"+el.id, {
          'showLineNumbers': true,
          'wrapAminoAcids': true,
          'charsPerLine': 60,
          'toolbar': true,
          'search': true,
          'title' : x.protein,
          'sequenceMaxHeight': "300px",
          'badge': true
        });
      },

      resize: function(width, height) {

        // TODO: code to re-render the widget with a new size

      }

    };
  }
});