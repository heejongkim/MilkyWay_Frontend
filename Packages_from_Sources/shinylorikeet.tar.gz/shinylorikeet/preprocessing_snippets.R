setwd('/Users/heejongkim/github/proteomics')
#devtools::create("pvizjs")
setwd('pvizjs')
#htmlwidgets::scaffoldWidget("pvizjs")
devtools::install()
library(pvizjs)
pvizjs("..")

#########
setwd('/Users/heejongkim/github/proteomics')
#devtools::create("shinylorikeet")
setwd('shinylorikeet')
#htmlwidgets::scaffoldWidget("shinylorikeet")
devtools::install()
library(shinylorikeet)
shinylorikeet(sequence, scanNum, charge, precursorMz, fileName, variableMods, peaks)
# 2289 <- two mods
# 195 <- one mods
# 100 <- no mods
index_num = 100
# initial variable assignments
modSeq <- as.character(psm_table[index_num,]$sequence)
sequence <- as.character(psm_table[index_num,]$`unmodified sequence`)
scanNum <- psm_table[index_num,]$scan
fileName <- as.character(psm_table[index_num,]$file)
charge <- psm_table[index_num,]$charge
precursorMz <- psm_table[index_num,]$`spectrum precursor m/z`

# peak processing for lorikeet
selectedMS2 <- ms2_scans[ms2_scans$`File Name` == psm_table[index_num,]$file & ms2_scans$`scan index` == psm_table[index_num,]$scan-1,]
intensitiesMS2 <- matrix(as.numeric(unlist(strsplit(as.vector(selectedMS2$`intensity array`), ','))), ncol=1)
mzMS2 <- matrix(as.numeric(unlist(strsplit(as.vector(selectedMS2$`m/z array`), ','))),  ncol=1)
peaks <- cbind(mzMS2, intensitiesMS2)

# Obtain modification notation indexes
left_bracket <- unlist(gregexpr(pattern ='\\[',modSeq))
right_bracket <- unlist(gregexpr(pattern ='\\]',modSeq))
if(!grepl("\\[", modSeq)){
  variableMods <- ""
}else{
  # variableMods dataframe setup
  variableMods <- cbind.data.frame(left_bracket, right_bracket)
  variableMods["index"] <- NA
  variableMods["modMass"] <- NA
  variableMods["aminoAcid"] <- NA
  
  # Processing index, aminoacid letter, and modMass
  previous_right_bracket = 0
  previous_index = 0
  for (i in 1:nrow(variableMods)){
    print(i)
    print(variableMods[row.names(variableMods)==i,])
    if((variableMods[row.names(variableMods)==i,]$left_bracket-previous_right_bracket)==1){
      print("Nterminal Mod!")
      variableMods[row.names(variableMods)==i,]$modMass <- as.numeric(substr(modSeq, variableMods[row.names(variableMods)==i,]$left_bracket + 2, variableMods[row.names(variableMods)==i,]$right_bracket - 1))
      variableMods[row.names(variableMods)==i,]$index <- 1
      variableMods[row.names(variableMods)==i,]$aminoAcid <- substr(sequence, variableMods[row.names(variableMods)==i,]$index, variableMods[row.names(variableMods)==i,]$index)
      previous_right_bracket <- variableMods[row.names(variableMods)==i,]$right_bracket
  
    }else if((variableMods[row.names(variableMods)==i,]$left_bracket-previous_right_bracket)==2){
      print("first aa")
      variableMods[row.names(variableMods)==i,]$modMass <- as.numeric(substr(modSeq, variableMods[row.names(variableMods)==i,]$left_bracket + 2, variableMods[row.names(variableMods)==i,]$right_bracket - 1))
      variableMods[row.names(variableMods)==i,]$index <- 1
      variableMods[row.names(variableMods)==i,]$aminoAcid <- substr(sequence, variableMods[row.names(variableMods)==i,]$index, variableMods[row.names(variableMods)==i,]$index)
      previous_right_bracket <- variableMods[row.names(variableMods)==i,]$right_bracket
  
    }else{
      print("something in the middle")
      variableMods[row.names(variableMods)==i,]$modMass <- as.numeric(substr(modSeq, variableMods[row.names(variableMods)==i,]$left_bracket + 2, variableMods[row.names(variableMods)==i,]$right_bracket - 1))
      variableMods[row.names(variableMods)==i,]$index <- variableMods[row.names(variableMods)==i,]$left_bracket - previous_right_bracket + previous_index
      if(previous_right_bracket==0 & previous_index==0){
        variableMods[row.names(variableMods)==i,]$index <- variableMods[row.names(variableMods)==i,]$index - 1
      }
      variableMods[row.names(variableMods)==i,]$aminoAcid <- substr(sequence, variableMods[row.names(variableMods)==i,]$index, variableMods[row.names(variableMods)==i,]$index)
      previous_index <- variableMods[row.names(variableMods)==i,]$index - 1
      previous_right_bracket <- variableMods[row.names(variableMods)==i,]$right_bracket
    }
  }
  variableMods$left_bracket <- NULL
  variableMods$right_bracket <- NULL
}
shinylorikeet(sequence, scanNum, charge, precursorMz, fileName, variableMods, peaks)


