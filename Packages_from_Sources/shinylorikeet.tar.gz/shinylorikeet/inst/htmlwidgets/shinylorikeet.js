HTMLWidgets.widget({

  name: 'shinylorikeet',

  type: 'output',

  factory: function(el, width, height) {

    // TODO: define shared variables for this instance

    return {

      renderValue: function(x) {
        //console.log(el);
        $('#ms2lorikeet').empty();
        $('#ms2lorikeet_qual').empty();
        /* render the spectrum with the given options */
        $(el).specview({sequence: x.sequence, 
                        scanNum: x.scanNum,
                        charge: x.charge,
                        precursorMz: x.precursorMz,
                        fileName: x.fileName,
                        variableMods: HTMLWidgets.dataframeToD3(x.variableMods),
                        peaks: x.peaks,
                        showMassErrorPlot: true,
                        massErrorPlotDefaultUnit: 'ppm',
                        massError: 15,
                        massErrorUnit: 'ppm'
                        }); 

      },
      resize: function(width, height) {

        // TODO: code to re-render the widget with a new size

      }

    };
  }
});