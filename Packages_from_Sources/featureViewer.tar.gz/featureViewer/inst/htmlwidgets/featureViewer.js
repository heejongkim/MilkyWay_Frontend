HTMLWidgets.widget({

  name: 'featureViewer',

  type: 'output',

  factory: function(el, width, height) {

    // TODO: define shared variables for this instance

    return {

      renderValue: function(x) {

        
        $("#"+el.id).empty();
        //Create a new Feature Viewer and add some rendering options
        var options = {showAxis: true, showSequence: true,
                       brushActive: true, toolbar:true,
                       bubbleHelp: false, zoomMax:20 };
        var ft = new FeatureViewer(x.sequence,"#"+el.id, options);
        
        var feature_json = HTMLWidgets.dataframeToD3(x.feature_df);
        var grouped_feature = d3.nest()
          .key(function(d){return d.category;})
          .entries(feature_json);
        //console.log(x.feature_df);
        //console.log(feature_json);
        //console.log(grouped_feature);
        console.log()        
        for (let each of grouped_feature){
          ft.addFeature({
            data: Object.values(each)[1],
            name: Object.values(each)[0],
            color: "#81BEAA",
            type: "rect"
          });
        }
        ft.onFeatureSelected(function (d){
          Shiny.onInputChange(el.id+"_selected", d.detail);
        });
        $("#"+el.id).dblclick(function(){
          Shiny.onInputChange(el.id+"_selected", null);
        });
      },

      resize: function(width, height) {

        // TODO: code to re-render the widget with a new size

      }

    };
  }
});